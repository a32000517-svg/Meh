# Mehfil Events Website

A responsive single-page event-planning website built with plain HTML, CSS and JavaScript.

## Run locally
Open `index.html` in a browser. For a local server, run:
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000`.

## Deploy
Upload `index.html` to any static hosting provider (Netlify, Vercel, GitHub Pages, Cloudflare Pages). No build step is required.

## Before publishing
- Replace gallery images with your own event photography (current images are illustrative remote Unsplash images).
- Replace sample testimonials with genuine customer-approved reviews.
- Confirm package prices and what each package includes.
- If desired, add your business location, email, social media profiles, privacy policy and terms.
- The booking form opens WhatsApp with a pre-filled enquiry; the visitor must press Send in WhatsApp. This static version does not store form submissions.

## Contact links
- Phone: `tel:+918217722870`
- WhatsApp: `https://wa.me/918217722870`
